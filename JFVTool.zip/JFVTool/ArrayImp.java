package BPkg;
import AbstractPkg.*;
/*
*   Purpose: this class is a partial implementation of a data structure using an unsorted array to hold positive nonzero 
*            integer ID keys. Any empty element has a zero value and can be anywhere in the array.
*/
public class ArrayImp extends ArrayAbstract{
/*
*	Data structure description:
*	    The array "a" : is an unsorted array to hold positive nonzero integer ID keys. 
*                       Any empty element has a zero value and can be anywhere in the array.
*/	


/*
*   Purpose: a constructor to set the length of the array, 
*	         and initialize the array's elements to zeros (i.e. empty elements)
*/
	ArrayImp (int ArrayLength){
		super(ArrayLength);		
	}

/*	
*   <<Add method>>
*	Purpose: 
*     Insert the iD into the array if the array is not full and the iD does not exist in the array. 
*     The insertion must be in an empty element (i.e. zero value).
*	Specifications: 
*	  a)Pre-condition: 
*       The parameter “iD” > 0.
*	  b)Post-conditions:
*       1.If there is an empty element in the given array and the iD does not exist in the given array, 
*         then iD must be inserted into the array in an empty element and return the index of this element, no modification is performed to the other elements, 
*	    2.Otherwise, a negative integer is returned, and no modification is performed to any element.
*	  c)Invariant (i.e. a condition which must be true before and after the method completes):
*       The array “a” has unique elements with positive integer values if they are not empty. 
*/
	public int add(int iD) {
		//delete this statement and implement the method according to its specificactions
		return -1;
	}
	
/*
*   Please, ignore this method as you are not required to implemented it.
*/
	public int findIndexOfID(int iD){
		return -1;
	}

/*
*   Please, ignore this method as you are not required to implemented it.
*/
	public int delete(int iD) {
		return -1;
	}
}
