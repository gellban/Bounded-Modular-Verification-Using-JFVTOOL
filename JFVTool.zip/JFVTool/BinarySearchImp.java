package BPkg;
import AbstractPkg.*;
/*
*   Purpose: this class is a partial implementation of a data structure using using an unbalanced binary search tree "BST"
*            to hold positive nonzero integer keys
*/


public class BinarySearchImp extends BSTAbstract {
/*
*	Data structure description:
*	    The variable "root" : is used to reference the root node of the binary search tree. This tree can be unbalanced.
*                             Every node has 3 variables, which are: left, right, key. 
*/	

/*
*   Purpose: a constructor to set the "root" to null. This means that the BST is empty.
*/
	public BinarySearchImp () {
		super();
	}
	
/*	
*   <<iNewNode method>>
*	Purpose: 
*     Insert the iNewNode to BST.
*	Specifications: 
*	  a)Pre-condition: 
*       The parameter the key of “iNewNode” is greater than zero, 
*       and the left and right of "iNewNode” are null.
*	  b)Post-condition:
*       1.If the key of iNewNode is not an element in the given BST 
*         then the return is equal to 1, and the "iNewNode" has just been added to the BST
*	    2.Otherwise, the return is not equal to -1, and no modification is performed to any node in the BST
*	  c)Invariant (i.e. a condition which must be true before and after the method completes):
*       The BST is sorted such that the keys of the left side's nodes are less than their parents, 
*       and the keys of the left side's nodes are greater than their parents.
*       Also, the keys of BST are unique (i.e no duplicate).
*/
	public int addNode(Node iNewNode) {
		//delete this statement and implement the method according to its specificactions
		return -1;
	}

/*
*   Please, ignore this method as you are not required to implemented it.
*/
	public Node find(int iKey) {
		return null;
	}

	
/*
*   Please, ignore this method as you are not required to implemented it.
*/
	public int delNode(int iKey) {
		return -1;
	}
}
