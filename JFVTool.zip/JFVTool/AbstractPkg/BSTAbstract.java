package AbstractPkg;

import edu.mit.csail.sdg.annotations.*;

//The frame of the Binary Search Tree
@Invariant({
// a key in any left part of a Node should be less than the key of this Node
// this.left.^(left + right): ^ is the transitive closure unary operator;
// (navigational expressions, i.e this.root.^left=set of keys of left in root
		// Node)
//
		"all x : this.root.^(left + right) + this.root - null , L:(x.left.^(left + right) + x.left - null).key| L < x.key",
		// a key in any right part of a Node should be greater than the key of this Node
		"all x : this.root.^(left + right) + this.root - null , R:(x.right.^(left + right) + x.right - null).key| R > x.key" })
public abstract class BSTAbstract {
	// the nodes of (this) instance are distinct from the nodes of other instances of BSTAbstract
	@Invariant({
	"all x:(BSTAbstract - this-null),t:this.root.^(left+right)+this.root-null,xn:x.root.^(left+right)+x.root-null|!(xn=t)" })
	public @Nullable Node root;

	public BSTAbstract() {
		root = null;
	}
/*
	// if the find method finds iKey then it should be in one node of the binary search tree
	@Ensures({ "(return - null).key =@arg(0)&& @arg(0) in (this.root + this.root.^(left + right)-null).key"
			+ "||"
			+ "return = null && !(@arg(0) in (this.root + this.root.^(left + right)-null).key)" })
	@Pure
*/
        @Ensures("return == null")
	public abstract Node find(int iKey);

	@Invariant({ "this.key > 0", })
	public static class Node {
		public @Nullable
		Node left, right;
		public int key;

		public Node(int key) {
			this.left = null;
			this.right = null;
			this.key = key;
		}
	}
/*
	@Requires({
			// the new node does not exist in "this" instance's nodes
			"!(@arg(0).key in (this.root + this.root.^(left + right)-null).key)",
			// the new node does not exist in the other instances(i.e. not "this") nodes
			"!(@arg(0) in (BSTAbstract - this-null).root.^(left+right)+(BSTAbstract - this-null).root-null)",
			"@arg(0).(left + right) = null", "no root.@arg(0)" })
	// ensure:if return =1 then the new node must be in the BST else the BST does not change
	@Ensures("return==1 ? ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null) + @arg(0)))"
			+ " : ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null)))")
	@Modifies("Node.*,this.root, @arg(0).*")
*/	
	@Requires({
		// the new node has key > 0 
		"@arg(0).key >0",
		// the new node has left&right==null
		"@arg(0).(left + right) = null",
		// the new node does not exist in the other instances(i.e. not "this") nodes
		"!(@arg(0) in (BSTAbstract - this-null).root.^(left+right)+(BSTAbstract - this-null).root-null)",
//		"no root.@arg(0)" 
		})
	//if the key of iNewNode is not an element in BST(old)
	@Ensures("!(@arg(0).key in @old((this.root + this.root.^(left + right)-null).key))"
			//then return 1"
			+"? return==1 &&"
			//and make sure that the iNewNode has been add to BST
			+"((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null) + @arg(0)))"
			//else return any value except 1"
			+": return!=1 &&"
			//make sure that there is no changes to the BST
			+"((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null)))"
			)
	@Modifies("Node.*,this.root, @arg(0).*")
	public abstract int addNode(Node iNewNode);
/*	
	@Requires({			
			"this.root !=null",// to resolve java.lang.NullPointerException
			// the new node exists in "this" nodes
			"(@arg(0) in (this.root + this.root.^(left + right)-null).key)",
			// the new node does not exist in other instances(not "this") nodes
			"!(@arg(0) in ((BSTAbstract - this-null).root.^(left+right)+(BSTAbstract - this-null).root-null).key)",
			"no root.@arg(0)", "@arg(0)>0" })
	// ensure:if return =1 then the new node must not be in the BST else the new node is no change in the BST
	@Ensures("return==1 ? ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null) - BSTAbstract$Node@key.@arg(0)))"
			+ " : ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null)))")
	@Modifies("Node.*,this.root")
*/
/*	
	@Requires({			
		"this.root !=null",// to resolve java.lang.NullPointerException
		// the the iKey's node does not exist in other instances(not "this") nodes
		"!(@arg(0) in ((BSTAbstract - this-null).root.^(left+right)+(BSTAbstract - this-null).root-null).key)",
		"no root.@arg(0)", "@arg(0)>0" })
// ensure:if return =1 then the new node must not be in the BST else the new node is no change in the BST
@Ensures(
		//if iKey's node exists in "this" nodes
		"@old(@arg(0) in (this.root + this.root.^(left + right)-null).key)"+
		//then return==1 and delete the iKeys node from the nodes
		"? return==1 && ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null) - BSTAbstract$Node@key.@arg(0)))"
		//else do not modify the nodes (i.e. no deletion) or delete any node
		+ " : ((this.root + this.root.^(left + right)-null) = @old((this.root + this.root.^(left + right)-null)))")
@Modifies("Node.*,this.root")
*/
        @Ensures("return == -1")
	public abstract int delNode(int iKey);
}
