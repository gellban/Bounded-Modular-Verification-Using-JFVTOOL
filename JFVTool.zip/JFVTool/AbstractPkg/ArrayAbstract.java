package AbstractPkg;

import edu.mit.csail.sdg.annotations.Ensures;
import edu.mit.csail.sdg.annotations.Helper;
import edu.mit.csail.sdg.annotations.Invariant;
import edu.mit.csail.sdg.annotations.Modifies;
import edu.mit.csail.sdg.annotations.Requires;

@Invariant({
		" (all i2 : int | this.a[i2]!=null && this.a[i2]>=0)",
		"this.a!= null ",
		"all i:int , j : int |  0<=i && i<j && j<this.a.length =>  this.a[i]!=this.a[j] || this.a[i]=0 " })
public abstract class ArrayAbstract {
	public int[] a;
	public ArrayAbstract(int ArrayLength) {
		this.a = new int[ArrayLength];
		for (int ii = 0; ii < this.a.length; ii++) {
			this.a[ii] = 0;
		}
	}
	@Requires({ "@arg(0) > 0" })
	@Ensures({ "(some i3 : int | @old(this.a[i3]) == 0) && (all i3 : int | @old(this.a[i3]) != @arg(0))"+
		"? this.a[return] == @arg(0)&&(all i3 : int | (i3==return&&@old(this.a[i3])=0) || @old(this.a[i3]) == this.a[i3]) "+
		": return < 0 && (all i3 : int | @old(this.a[i3]) == this.a[i3])" 
	})
	@Modifies(" this.a.elems")
	abstract public int add(int iD);

//	@Requires({ "@arg(0) > 0" })
//	@Ensures("(some i3 : int | 0<=i3 && i3< this.a.length && this.a[i3] = @arg(0)) ? this.a[return] = @arg(0) : return < 0")
	@Ensures("return == -1")
	abstract public int findIndexOfID(int iD);

//	@Requires({ "@arg(0) > 0"})
//	@Ensures({ "(some i3 : int | @old(this.a[i3]) = @arg(0))  ? this.a[return] = 0 : return < 0" })
//	@Modifies(" this.a.elems")
	@Ensures("return == -1")
	abstract public int delete(int iD);
}
