javac -classpath lib/annotations.jar:./ BinarySearchImp.java
mv BinarySearchImp.class BPkg/ 
java -jar JFVTool.jar BPkg BinarySearchImp lib/ superclass Yes
