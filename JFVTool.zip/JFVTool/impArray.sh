javac -classpath lib/annotations.jar:./ ArrayImp.java
mv ArrayImp.class BPkg/ 
java -jar JFVTool.jar BPkg ArrayImp lib/ superclass Yes
